﻿//using System;
//using System.Net.Http;
//using System.Threading.Tasks;
//using System.Web.Mvc;

//namespace Onboarding.Controllers
//{
//    public class WeatherController : Controller
//    {
//        // GET: /Weather/
//        public ActionResult Index()
//        {
//            // This action method is responsible for handling requests to /Weather/Index

//            // You can call getWeatherData function to get weather data
//            double latitude = -34.04;
//            double longitude = 151.1;
//            getWeatherData(latitude, longitude);

//            // Assuming you want to display weather data in a view, you can return a view here
//            return View();
//        }

//        // You can define other action methods as needed for handling different requests
//    }
//}
